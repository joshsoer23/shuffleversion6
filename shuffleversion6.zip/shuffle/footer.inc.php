<section id="footer"> 
          	<img src="images/SundaeMediaLogo.png" width="100%" height="" alt="sundae media logo" />
    		<p>Powered by Sundae Media</p>
	<div id="social">
	<a href="index.php" class="logo"><strong>Shuffle</strong><?php echo $pageTitle ?></a>
	ul class="list-inline">
            <li class="list-inline-item"> <a class="btn-social btn-outline" href="https://www.facebook.com/twistedmediauk/" target="_blank"> <i class="fa fa-fw fa-facebook"></i> </a></li>
            <li class="list-inline-item"> <a class="btn-social btn-outline" href="https://plus.google.com/u/0/b/105829407991221698553/105829407991221698553" target="_blank"> <i class="fa fa-fw fa-google-plus"></i> </a></li>
            <li class="list-inline-item"> <a class="btn-social btn-outline" href="https://twitter.com/TwistedMedia1" target="_blank"> <i class="fa fa-fw fa-twitter"></i> </a></li>
            <li class="list-inline-item"> <a class="btn-social btn-outline" href="https://www.linkedin.com/company/18291716/" target="_blank"> <i class="fa fa-fw fa-linkedin"></i> </a></li>
            <li class="list-inline-item"> <a class="btn-social btn-outline" href="https://twistedmediauk.tumblr.com/" target="_blank"> <i class="fa fa-fw fa-tumblr"></i> </a></li>
            <li class="list-inline-item"> <a class="btn-social btn-outline" href="https://www.youtube.com/channel/UCjTe6b7uf6nZUZNenq23VUw" target="_blank"> <i class="fa fa-fw fa-youtube"></i> </a></li>
            <li class="list-inline-item"> <a class="btn-social btn-outline" href="https://www.instagram.com/twisted.media/" target="_blank"> <i class="fa fa-fw fa-instagram"></i> </a></li>
          </ul>
</div>
  		</section>