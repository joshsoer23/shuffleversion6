<?php

//set connectoion variables to match DB details
$host = "10.169.0.169";
$username = "joshsoer_shuffle";
$password = "shuffle1";
$database = "joshsoer_shuffle";


//connect to database
$dbconnection = mysqli_connect($host, $username, $password, $database);


//check if connected, exit if not
if(!$dbconnection) {
	exit("Database could not be connected.");
}
